library(testthat)

test_check("rgenoud")
